# fast_tasks
An application that provide fun, powerful and simple way to deal with daily tasks.
